using Game.Core;
using UnityEngine;
using Zenject;
using TMPro;
using Game.Core.Signals;
using Game.Infrastructure;

namespace Game.Presentation.UI
{
    public class ScoreTextView : MonoBehaviour
    {
        [SerializeField] private TMP_Text text;

        private IScoreService _score;
        private SignalBus _bus;

        [Inject]
        public void Construct(IScoreService score, SignalBus bus)
        {
            _score = score;
            _bus = bus;
        }

        private void OnEnable()
        {
            _bus.Subscribe<GameStartedSignal>(Refresh);
            _bus.Subscribe<PlayerScoredSignal>(_ => Refresh());
        }

        private void OnDisable()
        {
            _bus.Unsubscribe<GameStartedSignal>(Refresh);
            _bus.Unsubscribe<PlayerScoredSignal>(_ => Refresh()); // см. примечание ниже
        }

        private void Refresh() => text.text = _score.Value.ToString();
    }
}