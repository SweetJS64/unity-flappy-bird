using Zenject;
using Game.Core;
using Game.Core.Signals;
using UnityEngine;
using System;

namespace Game.Infrastructure
{
    public class ScoreService : IScoreService, IInitializable, IDisposable
    {
        private readonly SignalBus _bus;
        private const string BestKey = "BestScore";

        public int Value { get; private set; }
        public int Best  { get; private set; }

        public ScoreService(SignalBus bus)
        {
            _bus = bus;
        }

        // Zenject вызывает это сразу после биндингов
        public void Initialize()
        {
            Best = PlayerPrefs.GetInt(BestKey, 0);

            _bus.Subscribe<GameStartedSignal>(OnStarted);
            _bus.Subscribe<PlayerScoredSignal>(OnScored);
            _bus.Subscribe<PlayerDiedSignal>(OnDied);
        }

        // Zenject вызовет это при разрушении контейнера (например, при перезагрузке сцены)
        public void Dispose()
        {
            _bus.Unsubscribe<GameStartedSignal>(OnStarted);
            _bus.Unsubscribe<PlayerScoredSignal>(OnScored);
            _bus.Unsubscribe<PlayerDiedSignal>(OnDied);
        }

        private void OnStarted() => Value = 0;

        private void OnScored(PlayerScoredSignal sig)
        {
            Value += sig.Value;
        }

        private void OnDied()
        {
            if (Value > Best)
            {
                Best = Value;
                PlayerPrefs.SetInt(BestKey, Best);
                PlayerPrefs.Save();
            }
        }
    }
}